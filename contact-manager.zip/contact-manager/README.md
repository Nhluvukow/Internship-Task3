# Contact Manager

A simple program to manage contact information in a CSV file.

## Features
- Add, view, and save contacts.
- Stores contacts in a CSV file.

## Usage
Run the program and choose options to manage your contacts.