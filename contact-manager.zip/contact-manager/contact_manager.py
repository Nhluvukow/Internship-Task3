import csv

def load_contacts(filename):
    try:
        with open(filename, mode='r') as file:
            return list(csv.DictReader(file))
    except FileNotFoundError:
        return []

def save_contacts(contacts, filename):
    with open(filename, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=["Name", "Phone", "Email"])
        writer.writeheader()
        writer.writerows(contacts)

def display_contacts(contacts):
    for contact in contacts:
        print(f"Name: {contact['Name']}, Phone: {contact['Phone']}, Email: {contact['Email']}")

def main():
    contacts = load_contacts("contacts.csv")
    while True:
        print("1. Add Contact  2. View Contacts  3. Exit")
        choice = input("Choose an option: ")
        if choice == "1":
            name = input("Name: ")
            phone = input("Phone: ")
            email = input("Email: ")
            contacts.append({"Name": name, "Phone": phone, "Email": email})
            save_contacts(contacts, "contacts.csv")
        elif choice == "2":
            display_contacts(contacts)
        elif choice == "3":
            break

if __name__ == "__main__":
    main()